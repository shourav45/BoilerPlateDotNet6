﻿
namespace Model.DTO
{
    public class CommonResponseDto
    {
        public string Message { get; set; }
        public string Status { get; set; }
        public object Data { get; set; }
    }
}
