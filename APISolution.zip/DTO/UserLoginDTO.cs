﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class UserLoginDTO
    {
      
        public string UserName { get; set; } = null!;
        public string UserPassword { get; set; } = null!;
        
    }
}
